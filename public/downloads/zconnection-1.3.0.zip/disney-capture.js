// Cattura Disney+ ISOLATED: stesso protocollo/coda di Netflix e Prime, clock contenuto.
(() => {
  globalThis.__zappDisneyCleanup?.();
  const adapter = globalThis.ZConnectionDisney,
    tracker = adapter.createTracker(),
    listeners = [];
  let disposed = false,
    last = null,
    lastSent = null,
    lastSentAt = 0,
    suspended = false,
    buffering = false;
  function send(type, current) {
    const dati = current
      ? {
          at: current.at,
          url: current.url,
          state: current.state,
          title: null,
          artist: null,
          album: null,
          titleText: current.raw.titleText,
          showText: null,
          pauseText: current.raw.detailText,
          contentKey: current.contentKey,
          playbackRate: current.playbackRate,
          positionMs: current.positionMs,
          durationMs: current.durationMs,
        }
      : null;
    try {
      chrome.runtime.sendMessage({ type, site: "disney", dati }).catch(() => {});
    } catch {
      /* Aggiornamento estensione. */
    }
  }
  function close() {
    if (last) send("evento", { ...last, at: new Date().toISOString(), state: "stopped" });
    last = null;
    lastSent = null;
    suspended = false;
    tracker.reset();
  }
  function sample(closing = false) {
    if (disposed) return;
    const o = closing ? null : adapter.observe(document, location.href);
    // Chiude solo su uscita/cambio contenuto provato. Un annuncio o un seek
    // sospende la sessione allo stesso minuto, senza usare i tempi pubblicitari.
    const sameAsset =
      last &&
      (() => {
        try {
          const current = new URL(location.href),
            old = new URL(last.url);
          return (
            current.origin === old.origin &&
            /^\/it-it\/play\//.test(current.pathname) &&
            current.pathname.replace(/\/$/, "").split("/").pop() ===
              old.pathname.replace(/\/$/, "").split("/").pop()
          );
        } catch {
          return false;
        }
      })();
    if (last && (closing || !sameAsset || (o && o.contentKey !== last.contentKey)))
      close();
    if (o && buffering) o.state = "paused";
    const current = tracker.update(o, Date.now());
    if (!current) {
      if (last && !suspended) {
        send("evento", { ...last, at: new Date().toISOString(), state: "paused" });
        suspended = true;
        lastSent = null;
      }
      send("disney-live", null);
      return;
    }
    last = current;
    suspended = false;
    send("disney-live", current);
    const key = JSON.stringify([current.contentKey, current.state]);
    if (key !== lastSent || Date.now() - lastSentAt >= 30000) {
      send("evento", current);
      lastSent = key;
      lastSentAt = Date.now();
    }
  }
  const on = (target, name, fn) => {
    target.addEventListener(name, fn, true);
    listeners.push(() => target.removeEventListener(name, fn, true));
  };
  for (const name of [
    "playing",
    "pause",
    "seeked",
    "seeking",
    "ratechange",
    "ended",
    "loadedmetadata",
    "waiting",
    "emptied",
  ]) {
    on(document, name, (event) => {
      if (event.target?.tagName !== "VIDEO") return;
      const o = adapter.observe(document, location.href);
      if (o && o.video !== event.target) return;
      if (name === "waiting") buffering = true;
      if (["playing", "seeked", "loadedmetadata", "emptied"].includes(name))
        buffering = false;
      sample();
    });
  }
  on(document, "visibilitychange", () => sample());
  on(window, "pagehide", () => sample(true));
  on(window, "pageshow", () => {
    tracker.reset();
    sample();
  });
  const runtime = (msg, _sender, reply) => {
    if (msg?.type === "zapp-ping") {
      reply({ ok: true });
      return false;
    }
    if (msg?.type === "zapp-refresh") {
      sample();
      reply({ ok: true });
      return false;
    }
    return false;
  };
  chrome.runtime.onMessage.addListener(runtime);
  const timer = setInterval(() => sample(), 1000);
  globalThis.__zappDisneyCleanup = () => {
    disposed = true;
    clearInterval(timer);
    listeners.forEach((fn) => fn());
    chrome.runtime.onMessage.removeListener(runtime);
  };
  sample();
})();
