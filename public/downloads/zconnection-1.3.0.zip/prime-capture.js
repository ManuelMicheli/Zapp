﻿// Esegue nel mondo ISOLATED: accede al DOM, mai alle API private del player.
(() => {
  globalThis.__zappPrimeCleanup?.();
  const tracker = globalThis.ZConnectionPrime.createTracker();
  const listeners = [];
  let lastSent = null, lastSentAt = 0, disposed = false;
  let buffering = false;
  const epochs = new WeakMap();
  function send(type, dati) {
    try { chrome.runtime.sendMessage({ type, site: 'prime', dati }).catch(() => {}); }
    catch { /* Estensione aggiornata: non interrompere la pagina. */ }
  }
  function payload(current) {
    if (!current) return null;
    return {at:current.at,url:current.url,state:current.state,
      title:null,artist:null,album:null,titleText:current.raw.titleText,
      showText:null,pauseText:current.raw.detailText,
      contentKey:current.contentKey,playbackRate:current.playbackRate,
      positionMs:current.positionMs,durationMs:current.durationMs};
  }
  function sample(force = false, refreshOnly = false, closing = false) {
    if (disposed) return;
    let observation = closing ? null : globalThis.ZConnectionPrime.observe(document, location.href);
    if (observation) {
      observation.mediaEpoch = epochs.get(observation.video) ?? 0;
      if (buffering) observation.state = 'paused';
    }
    const {current, closed} = tracker.update(observation, new Date().toISOString());
    if (closed) { send('evento',payload(closed)); lastSent=null; }
    send('prime-live',payload(current));
    if (!current || refreshOnly) return;
    const key = JSON.stringify([current.contentKey,current.state]);
    if (force || key !== lastSent || Date.now()-lastSentAt >= 30000) {
      send('evento',payload(current)); lastSent=key;lastSentAt=Date.now();
    }
  }
  function on(name, fn, target = document) {
    target.addEventListener(name,fn,true);
    listeners.push(()=>target.removeEventListener(name,fn,true));
  }
  for (const name of ['playing','pause','seeked','ratechange','ended','loadedmetadata','waiting','emptied']) {
    on(name,event=>{
      // Non reagire alle anteprime quando il video selezionato e' un altro.
      const o=globalThis.ZConnectionPrime.observe(document,location.href);
      if (o && event.target !== o.video) return;
      if(name==='loadedmetadata') epochs.set(event.target,(epochs.get(event.target) ?? 0)+1);
      if(name==='waiting') buffering=true;
      if(['playing','seeked','loadedmetadata','emptied'].includes(name)) buffering=false;
      sample(true);
    });
  }
  on('visibilitychange',()=>sample(true));
  on('pagehide',()=>sample(false,false,true),window);
  on('pageshow',()=>{tracker.reset();sample(true);},window);
  const runtime = (msg,_sender,reply) => {
    if(msg?.type==='zapp-ping'){reply({ok:true});return false;}
    if(msg?.type==='zapp-refresh'){sample(false,true);reply({ok:true});return false;}
    return false;
  };
  chrome.runtime.onMessage.addListener(runtime);
  // Il popup riceve misure locali frequenti; il salvataggio usa il proprio ritmo.
  const timer=setInterval(()=>sample(),1000);
  globalThis.__zappPrimeCleanup=()=>{
    disposed=true;clearInterval(timer);listeners.forEach(remove=>remove());
    chrome.runtime.onMessage.removeListener(runtime);
  };
  sample();
})();
